DWORD MKF_GetRecordCount(FILE *fp);
LONG MKF_ReadRecord(LPBYTE lpBuffer, DWORD dwBufferLength, DWORD dwRecord, FILE *fp);
