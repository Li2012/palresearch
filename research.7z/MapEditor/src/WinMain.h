#ifndef _WINMAIN_H_
#define _WINMAIN_H_

#endif //_WINMAIN_H_