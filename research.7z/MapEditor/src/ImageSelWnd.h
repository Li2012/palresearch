BOOL ImageSelWnd_Create(HWND hWndParent);
VOID ImageSelWnd_Update(VOID);
LONG ImageSelWnd_GetSelImage(VOID);
VOID ImageSelWnd_SizeParent(RECT *lpRect);