#ifndef _PALETTE_H_
#define _PALETTE_H_

BOOL Palette_Init(RGBQUAD *pPalette);

#endif //_PALETTE_H_