//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resource.rc
//
#define IDR_TOOLBAR_MAIN                103
#define IDR_TOOLBAR                     103
#define IDR_MENU                        105
#define IDR_ACCELERATOR                 107
#define IDD_ABOUTDIALOG                 109
#define IDD_TILEATTRIBUTEDIALOG         110
#define IDI_ICON                        113
#define IDB_BITMAP1                     114
#define IDB_BITMAP2                     115
#define IDB_BITMAP3                     117
#define IDI_ICON_TEMPLATEEDIT           126
#define IDI_ICON_MAPEDIT                127
#define IDB_BITMAP4                     136
#define IDB_BITMAP5                     137
#define IDC_EDIT_IMAGE0                 1001
#define IDC_EDIT_IMAGE1                 1002
#define IDC_EDIT_HEIGHT0                1004
#define IDC_EDIT_HEIGHT1                1005
#define IDC_BUTTON0                     1007
#define IDC_BUTTON1                     1008
#define IDC_CHECK_BARRIER               1012
#define IDCMD_VIEW_OBJECT               40034
#define IDCMD_VIEW_TILEATTRIBUTEWND     40038
#define IDCMD_EDIT_TEMPLATE             40065
#define IDCMD_FILE_OPEN                 40078
#define IDCMD_FILE_NEW                  40079
#define IDCMD_FILE_SAVE                 40080
#define IDCMD_APP_EXIT                  40081
#define IDCMD_EDIT_SELECT               40082
#define IDCMD_EDIT_PEN                  40083
#define IDCMD_EDIT_ERASE                40084
#define IDCMD_EDIT_BARRIER              40085
#define IDCMD_EDIT_LAYER0               40086
#define IDCMD_EDIT_LAYER1               40087
#define IDCMD_VIEW_BARRIER              40088
#define IDCMD_WINDOW_MAPEDITWND         40089
#define IDCMD_WINDOW_TEMPLATEEDITWND    40090
#define IDCMD_APP_ABOUT                 40091
#define IDCMD_VIEW_MINIMAPWND           40092
#define IDCMD_TEMPLATE_CLEAR            40093
#define IDCMD_TEMPLATE_AIPASTER         40095

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         40096
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
