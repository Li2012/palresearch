/********************************************************************************\
|
|	Name:
|		
|
|	Description:
|		
|
\********************************************************************************/
/*
#ifndef _STDAFX_
#define	_STDAFX_

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "msimg32.lib")

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include <assert.h>
#include <vector>
#include "resource.h"

#include "Wnd.h"
#include "Menu.h"

#define SafeDelete(pObject)\
if(pObject != NULL)\
{\
	delete pObject;\
	pObject = NULL;\
}\

#define SafeDeleteArray(pObject)\
if(pObject != NULL)\
{\
	delete [] pObject;\
	pObject = NULL;\
}\


#endif*/