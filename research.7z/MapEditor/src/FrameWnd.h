#ifndef _FRAMEWND_H_
#define _FRAMEWND_H_

BOOL FrameWnd_Create(HINSTANCE hInstance);

#endif //_FRAMEWND_H_